# SEMBULUNG NAVIGATOR — V8 Production ENC Engine

Version: **0.8.0-production-enc**  
Brand: **SEMBULUNG NAVIGATOR — BY WONG MBRAYU**

V8 moves the project from prototype chart inspection toward a production-oriented Android build and a native ENC integration boundary.

## What is new in V8

- Android production build structure: JDK 17, Gradle 8.7 bootstrap scripts, CMake/JNI, debug/release build types, environment-based release signing, and GitHub Actions CI.
- Native `sn_enc` bridge always builds. Without GDAL it reports `STUB`; with a compatible Android GDAL build it reports `GDAL_S57`.
- Optional GDAL S-57 import path for `.000` plus `.001/.002/...` updates stored beside the base cell.
- S-57 mapping to the internal chart model for depth areas/contours, soundings, buoys, beacons, lights/light sectors, daymarks, wrecks, rocks, obstructions, land and coastline.
- Day / Dusk / Night **S-52-inspired** portrayal layer. It is not certified ECDIS portrayal.
- SAF folder import to keep S-57 base cells and update files together.
- Runtime data installer for `s57objectclasses.csv` and `s57attributes.csv` supplied with the GDAL distribution you choose to bundle.
- Explicit S-63 licensed-security-module boundary. No S-63 decryption or protection bypass is included.
- Existing V1–V7 navigation, AIS, sonar, safety routing, GPX, weather, offline map, MOB and activation features are retained.

## Build debug

Requirements on the build computer:

- Android Studio / Android SDK 35
- JDK 17
- Android NDK + CMake (only needed because the native ENC stub is compiled)
- Internet access on the first Gradle bootstrap, unless Gradle 8.7 is already installed

```bash
./scripts/verify_project.sh
./scripts/build_debug.sh
```

Output after a successful Android SDK build:

`app/build/outputs/apk/debug/app-debug.apk`

## Release signing

No private signing key is included. Set these environment variables:

```bash
export SN_RELEASE_STORE_FILE=/secure/path/release.keystore
export SN_RELEASE_STORE_PASSWORD='...'
export SN_RELEASE_KEY_ALIAS='...'
export SN_RELEASE_KEY_PASSWORD='...'
./scripts/build_release.sh
```

## Enable native S-57 with GDAL

V8 intentionally does **not** bundle an arbitrary third-party GDAL binary. Add a compatible Android GDAL build under:

- `app/src/main/gdal/include/`
- `app/src/main/gdal/jniLibs/<ABI>/libgdal.so`
- S-57 CSV runtime catalog files under `app/src/main/assets/gdal/s57/`

See `docs/GDAL_ANDROID_INTEGRATION_V8.md`.

## Important navigation limitation

This project is not a type-approved ECDIS and must not be represented as one. Route hazards, safety depth, CPA/TCPA, community/offline maps, weather models and sonar overlays are advisory. Use official charts and appropriately certified/maintained equipment for safety-critical navigation.

## Protected ENC

S-63 protected ENC must use valid permits and a licensed/approved security implementation. V8 provides only an interface boundary (`LicensedS63SecurityModule`).
