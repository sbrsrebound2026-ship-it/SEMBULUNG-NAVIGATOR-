#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Install Gradle 8.7, lalu jalankan script ini." >&2; exit 2
fi
cd "$ROOT"
gradle wrapper --gradle-version 8.7 --distribution-type bin
