#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${SN_RELEASE_STORE_FILE:?set SN_RELEASE_STORE_FILE}"
: "${SN_RELEASE_STORE_PASSWORD:?set SN_RELEASE_STORE_PASSWORD}"
: "${SN_RELEASE_KEY_ALIAS:?set SN_RELEASE_KEY_ALIAS}"
: "${SN_RELEASE_KEY_PASSWORD:?set SN_RELEASE_KEY_PASSWORD}"
"$ROOT/scripts/verify_project.sh"
exec "$ROOT/gradlew" --no-daemon clean assembleRelease
