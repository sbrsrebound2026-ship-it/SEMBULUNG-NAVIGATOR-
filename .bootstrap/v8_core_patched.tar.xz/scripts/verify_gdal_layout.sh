#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BASE="$ROOT/app/src/main/gdal"
missing=0
for f in "$BASE/include/gdal.h" "$ROOT/app/src/main/assets/gdal/s57/s57objectclasses.csv" "$ROOT/app/src/main/assets/gdal/s57/s57attributes.csv"; do
  if [ ! -f "$f" ]; then echo "MISSING: $f"; missing=1; fi
done
for abi in arm64-v8a armeabi-v7a x86_64; do
  [ -f "$BASE/jniLibs/$abi/libgdal.so" ] || { echo "MISSING: $BASE/jniLibs/$abi/libgdal.so"; missing=1; }
done
if [ "$missing" -ne 0 ]; then
  echo "GDAL mode belum lengkap; project tetap dapat dibuild dalam STUB mode."
  exit 3
fi
echo "GDAL layout OK"
