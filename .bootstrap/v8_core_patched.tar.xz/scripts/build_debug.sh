#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
"$ROOT/scripts/verify_project.sh"
exec "$ROOT/gradlew" --no-daemon clean assembleDebug
