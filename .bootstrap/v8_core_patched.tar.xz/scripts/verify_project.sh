#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
req=(
  "$ROOT/app/src/main/AndroidManifest.xml"
  "$ROOT/app/src/main/cpp/CMakeLists.txt"
  "$ROOT/app/src/main/cpp/enc_bridge.cpp"
  "$ROOT/app/src/main/java/com/wongmbrayu/sembulungnavigator/NativeEncBridge.kt"
  "$ROOT/app/src/main/java/com/wongmbrayu/sembulungnavigator/S57NativeImporter.kt"
)
for f in "${req[@]}"; do test -f "$f" || { echo "MISSING: $f"; exit 1; }; done
if grep -RniE 'bypass_s63|decrypt_s63_without|crack_s63|force.*s63.*decrypt' "$ROOT/app/src/main"; then
  echo "Ditemukan pola implementasi S-63 yang tidak diperbolehkan"; exit 2
fi
echo "Structure QC OK"
