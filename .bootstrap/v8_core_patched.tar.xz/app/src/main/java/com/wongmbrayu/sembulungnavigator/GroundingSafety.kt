package com.wongmbrayu.sembulungnavigator

import android.content.Context

class RouteHazardSettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("route_hazard_v7", Context.MODE_PRIVATE)
    fun load() = RouteHazardSettings(
        enabled = prefs.getBoolean("enabled", true),
        corridorNm = prefs.getString("corridor_nm", "0.12")?.toDoubleOrNull() ?: 0.12,
        lookAheadNm = prefs.getString("lookahead_nm", "3.0")?.toDoubleOrNull() ?: 3.0,
        dangerAheadNm = prefs.getString("danger_nm", "0.50")?.toDoubleOrNull() ?: 0.50
    )
    fun save(v: RouteHazardSettings) = prefs.edit()
        .putBoolean("enabled", v.enabled)
        .putString("corridor_nm", v.corridorNm.coerceIn(0.02, 2.0).toString())
        .putString("lookahead_nm", v.lookAheadNm.coerceIn(0.2, 25.0).toString())
        .putString("danger_nm", v.dangerAheadNm.coerceIn(0.05, v.lookAheadNm.coerceAtLeast(0.05)).toString())
        .apply()
}

class GroundingAheadStore(context: Context) {
    private val prefs = context.getSharedPreferences("grounding_ahead_state_v7", Context.MODE_PRIVATE)
    fun save(state: GroundingAheadState) {
        val h = state.firstHazard
        val e = prefs.edit().putString("level", state.level?.name).putLong("updated", System.currentTimeMillis())
        if (h == null) e.remove("feature").remove("type").remove("name").remove("lat").remove("lon").remove("depth").remove("cross").remove("ahead").remove("eta").remove("severity").remove("reason")
        else e.putString("feature", h.featureId).putString("type", h.featureType.name).putString("name", h.name)
            .putString("lat", h.latitude.toString()).putString("lon", h.longitude.toString()).putString("depth", h.depthMeters?.toString())
            .putString("cross", h.distanceFromTrackNm.toString()).putString("ahead", h.distanceAheadNm.toString()).putString("eta", h.etaMinutes?.toString())
            .putString("severity", h.severity.name).putString("reason", h.reason)
        e.apply()
    }
    fun load(): GroundingAheadState {
        val feature = prefs.getString("feature", null)
        val hazard = if (feature == null) null else runCatching {
            RouteHazard(
                featureId = feature,
                featureType = ChartFeatureType.valueOf(prefs.getString("type", "UNKNOWN") ?: "UNKNOWN"),
                name = prefs.getString("name", null),
                latitude = prefs.getString("lat", "0")!!.toDouble(), longitude = prefs.getString("lon", "0")!!.toDouble(),
                depthMeters = prefs.getString("depth", null)?.toDoubleOrNull(),
                distanceFromTrackNm = prefs.getString("cross", "0")!!.toDouble(), distanceAheadNm = prefs.getString("ahead", "0")!!.toDouble(),
                etaMinutes = prefs.getString("eta", null)?.toDoubleOrNull(),
                severity = RouteHazardSeverity.valueOf(prefs.getString("severity", "WATCH") ?: "WATCH"),
                reason = prefs.getString("reason", "") ?: ""
            )
        }.getOrNull()
        val level = prefs.getString("level", null)?.let { runCatching { RouteHazardSeverity.valueOf(it) }.getOrNull() }
        return GroundingAheadState(level, hazard, listOfNotNull(hazard))
    }
}
