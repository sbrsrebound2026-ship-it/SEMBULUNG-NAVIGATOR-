Place GDAL S-57 runtime catalog files here before production build:
- s57objectclasses.csv
- s57attributes.csv

The V8 runtime copies these assets to app-private storage and sets S57_CSV.
Use files supplied with the GDAL build/distribution you are licensed to redistribute.
