Optional GDAL_DATA runtime files may be placed here when required by your GDAL Android build.
