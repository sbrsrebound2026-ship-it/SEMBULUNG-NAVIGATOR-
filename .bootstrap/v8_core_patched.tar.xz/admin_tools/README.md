# Admin Activation Tool

1. User opens SEMBULUNG NAVIGATOR and sends the displayed `Device Code`.
2. On the admin computer run:

```bash
python generate_activation_key.py SNV-XXXX-XXXX-XXXX
```

3. Send the generated `SNV1....` key to that user.
4. The app verifies the ECDSA signature using only the embedded **public key**.
5. The private key in `activation_private_key.pem` must stay with the app owner/admin and must **never** be copied into the Android APK or published.

If the app is installed on a different Android device, its Device Code changes and the old activation key will fail verification.
