#!/usr/bin/env python3
"""Generate an offline activation key for one SEMBULUNG NAVIGATOR Device Code.
Keep activation_private_key.pem secret and NEVER package it inside the APK.
"""
from pathlib import Path
import argparse, base64
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

parser = argparse.ArgumentParser()
parser.add_argument('device_code', help='Example: SNV-7Q4P-X2K9-81AD')
parser.add_argument('--private-key', default=str(Path(__file__).with_name('activation_private_key.pem')))
args = parser.parse_args()

code = args.device_code.strip().upper()
if not code.startswith('SNV-'):
    raise SystemExit('Device Code harus diawali SNV-')
private_key = serialization.load_pem_private_key(Path(args.private_key).read_bytes(), password=None)
sig = private_key.sign(code.encode('utf-8'), ec.ECDSA(hashes.SHA256()))
encoded = base64.urlsafe_b64encode(sig).decode().rstrip('=')
print('SNV1.' + encoded)
