\
@echo off
setlocal
set VER=8.7
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
set CACHE=%USERPROFILE%\.gradle\sembulung-bootstrap\gradle-%VER%
set BIN=%CACHE%\gradle-%VER%\bin\gradle.bat
if not exist "%BIN%" (
  if not exist "%CACHE%" mkdir "%CACHE%"
  set ZIP=%CACHE%\gradle-%VER%-bin.zip
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%VER%-bin.zip' -OutFile '%CACHE%\gradle-%VER%-bin.zip'; Expand-Archive -Force '%CACHE%\gradle-%VER%-bin.zip' '%CACHE%'"
)
call "%BIN%" -p "%~dp0" %*
exit /b %ERRORLEVEL%
